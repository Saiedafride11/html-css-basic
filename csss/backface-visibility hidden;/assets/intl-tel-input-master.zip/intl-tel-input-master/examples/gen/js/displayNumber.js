var input = document.querySelector("#phone");
window.intlTelInput(input, {
  utilsScript: "../../build/js/utils.js?1603274336113" // just for formatting/placeholders etc
});
