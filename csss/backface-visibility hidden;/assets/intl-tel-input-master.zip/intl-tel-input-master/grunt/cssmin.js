module.exports = function(grunt) {
  return {
    target: {
      files: {
        'build/css/intlTelInput.min.css': 'build/css/intlTelInput.css'
      }
    }
  };
};
